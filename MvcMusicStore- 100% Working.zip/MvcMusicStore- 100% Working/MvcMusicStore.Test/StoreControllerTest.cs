﻿using System;
using MvcMusicStore.Controllers;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MvcMusicStore.ViewModels;

namespace MvcMusicStore.Test
{
    [TestClass]
    public class StoreControllerTest
    {
        [TestMethod]
        public void IndexTest()
        {
            StoreController target = new StoreController();
            var viewModel = new StoreIndexViewModel();            
            var actual = target.Index() as ContentResult;
            Assert.AreEqual(viewModel, actual);

        }

        [TestMethod]
        public void DetailsTest()
        {
        }

        [TestMethod]
        public void BrowseTest()
        {
            StoreController target = new StoreController();
            string genre = "Disco";
            string expected = "Store.Browse, Genre = Disco";
            var actual = target.Browse(genre);
            Assert.AreEqual(expected, actual);
        }
    }
}
